# ============================================================
# STREAMLIT TEXT CLASSIFIER DASHBOARD (FINAL + METRICS UI)
# ============================================================

import streamlit as st
import pandas as pd
import numpy as np
import re

from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    classification_report, confusion_matrix, roc_auc_score, roc_curve
)

import matplotlib.pyplot as plt
import seaborn as sns
from mpl_toolkits.mplot3d import Axes3D  # 3D plotting
from matplotlib import cm  # colormap
import pandas as pd
import plotly.express as px



st.set_page_config(page_title="Twitter Sentiment Classifier", layout="wide")

# -----------------------------
# Cleaning function
# -----------------------------
def clean_tweet(text):
    text = str(text).lower()
    text = re.sub(r"http\S+|www\.\S+", "", text)
    text = re.sub(r"@\w+", "", text)
    text = re.sub(r"&amp;", "and", text)
    text = re.sub(r"rt[\s]+", "", text)
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

# -----------------------------
# Load CSV
# -----------------------------
def load_csv(uploaded_file):
    try:
        df = pd.read_csv(
            uploaded_file,
            encoding="latin-1",
            header=None,
            names=["target","id","date","flag","user","text"],
            quoting=1, quotechar='"', escapechar="\\",
            engine="python", on_bad_lines="skip"
        )
        return df
    except Exception as e:
        st.error(f"CSV уншихад алдаа: {e}")
        return None

# -----------------------------
# Prepare Data
# -----------------------------
def prepare_df(df):
    if "target" not in df.columns or "text" not in df.columns:
        st.error("CSV нь Twitter dataset хэлбэртэй байх ёстой.")
        return None
    if set(df["target"].unique()) == {0,4}:
        df["target"] = df["target"].map({0:0, 4:1})
    df["clean_text"] = df["text"].astype(str).apply(clean_tweet)
    return df

# -----------------------------
# Build pipelines
# -----------------------------
def build_pipelines():
    nb = Pipeline([
        ("vect", CountVectorizer(max_features=15000, ngram_range=(1,2))),
        ("clf", MultinomialNB())
    ])
    lr = Pipeline([
        ("vect", TfidfVectorizer(max_features=20000, ngram_range=(1,2))),
        ("clf", LogisticRegression(max_iter=1000, solver="liblinear"))
    ])
    return {"NaiveBayes": nb, "LogisticRegression": lr}

# -----------------------------
# Evaluate
# -----------------------------
def evaluate(model, X_test, y_test):
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:,1]
    return {
        "y_pred": y_pred,
        "y_proba": y_proba,
        "acc": accuracy_score(y_test, y_pred),
        "prec": precision_score(y_test, y_pred),
        "rec": recall_score(y_test, y_pred),
        "f1": f1_score(y_test, y_pred),
        "auc": roc_auc_score(y_test, y_proba),
        "cm": confusion_matrix(y_test, y_pred),
        "report": classification_report(y_test, y_pred, digits=4)
    }

# -----------------------------
# Streamlit UI
# -----------------------------
st.title("📊 Twitter Sentiment Classifier Dashboard")
st.markdown("Upload CSV → Train → Compare models → Posterior + Prediction + Correctness + Metrics")

uploaded_file = st.file_uploader("Upload CSV", type=["csv"])
test_size = st.slider("Test size (%)", 10, 50, 30)

if uploaded_file:
    df_raw = load_csv(uploaded_file)
    if df_raw is not None:
        st.subheader("CSV Preview")
        st.write(df_raw.head())

        df = prepare_df(df_raw)
        if df is not None:
            st.subheader("Dataset Summary")
            st.write(df["target"].value_counts())

            X = df["clean_text"]
            y = df["target"]
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=test_size/100, stratify=y, random_state=42
            )

            st.subheader("Training Models...")
            models = build_pipelines()
            results = {}
            bar = st.progress(0)
            for i, (name, model) in enumerate(models.items(), start=1):
                model.fit(X_train, y_train)
                results[name] = evaluate(model, X_test, y_test)
                bar.progress(int(i/len(models)*100))
            st.success("✅ Training Done!")

            # -----------------------------
            # Model Metrics Summary (card layout)
            # -----------------------------
            st.subheader("📌 Model Metrics Overview")
            for name, r in results.items():
                st.markdown(f"### {name}", unsafe_allow_html=True)

                # Metrics cards (smaller font, fit on screen)
                col1, col2, col3, col4 = st.columns(4)
                col1.metric("Accuracy", f"{r['acc'] * 100:.2f}%") 
                # col1.metric("Accuracy", f"{(r['acc']:.4f) * 100:.2f}%")
                col2.metric("Precision", f"{r['prec'] * 100:.2f}%")
                col3.metric("Recall", f"{r['rec'] * 100:.2f}%")
                col4.metric("F1 Score", f"{r['f1'] * 100:.2f}%")

            

            # -----------------------------
            # Posterior Probability Table (First 10 Tweets)
            # -----------------------------
            st.subheader("Posterior Probability Table (First 10 Tweets)")
            posterior_table = pd.DataFrame({"Tweet": X_test[:10], "True Label": y_test[:10]})
            for name, r in results.items():
                posterior_table[name+"_Posterior"] = r["y_proba"][:10]
                posterior_table[name+"_Prediction"] = r["y_pred"][:10]
                posterior_table[name+"_Correct?"] = r["y_pred"][:10] == y_test[:10]
            st.dataframe(posterior_table, height=400)

            # -----------------------------
            # Interactive Posterior + Prediction + Correctness
            # -----------------------------
            st.subheader("🔎 Interactive Posterior + Prediction")
            idx = st.slider("Select Tweet Index", 0, len(X_test)-1, 0)
            st.write("Tweet:", X_test.iloc[idx])
            st.write("Require True Label:", y_test.iloc[idx])
            for name, r in results.items():
                posterior = r["y_proba"][idx]
                pred = r["y_pred"][idx]
                correct = "✅ True" if pred == y_test.iloc[idx] else "❌ False"
                st.metric(label=f"{name} Posterior (+ probability)", value=f"{posterior * 100:.2f}%")
                st.write(f"{name} Prediction:", pred, "| Correct?", correct)

            st.subheader("🔎 Confusion Matrices (T/F row & column labels)")

            cols = st.columns(len(results))  # 2 models

            for col, (name, r) in zip(cols, results.items()):
                with col:
                    st.markdown(f"### {name}")

                    cm_vals = r["cm"]  # matrix утгуудыг хэвээр авчирна

                    fig, ax = plt.subplots(figsize=(5, 4))
                    sns.heatmap(
                        cm_vals,
                        annot=True,
                        fmt="d",
                        cmap="YlGnBu",
                        ax=ax,
                        annot_kws={"size":12, "weight":"bold"},
                        linewidths=1,
                        linecolor="white",
                        cbar=True
                    )

                    # Row (y) labels
                    ax.set_yticklabels(['T','F'], rotation=0, fontsize=11, weight='bold',  minor=False)
                    # Column (x) labels
                    ax.set_xticklabels(['F','T'], rotation=0, fontsize=11, weight='bold', minor=False)

                    ax.set_xlabel("Predicted", fontsize=10, weight="bold")
                    ax.set_ylabel("Actual", fontsize=10, weight="bold")
                    ax.set_title(f"{name} Confusion Matrix (T/F)", fontsize=12, weight="bold")
                    ax.tick_params(labelsize=10)
                  
                    st.pyplot(fig, use_container_width=True)


            # -----------------------------
            # Posterior Probability Distribution Histogram
            # -----------------------------
            st.subheader("🔎Posterior Probability Distribution (3D View)")

            # 2 columns for side-by-side display
            cols = st.columns(len(results))  # автомат 2 column болж тохирно

            for col, (name, r) in zip(cols, results.items()):
                with col:
                    fig = plt.figure(figsize=(5,4))
                    ax = fig.add_subplot(111, projection='3d')

                    # Histogram data
                    hist, bins = np.histogram(r["y_proba"], bins=25)
                    xpos = (bins[:-1] + bins[1:]) / 2
                    ypos = np.zeros_like(xpos)
                    zpos = np.zeros_like(xpos)
                    dx = (bins[1]-bins[0]) * np.ones_like(xpos)
                    dy = np.ones_like(xpos)
                    dz = hist

                    # Color mapping: higher bars darker
                    colors = cm.viridis(dz / dz.max())

                    ax.bar3d(xpos, ypos, zpos, dx, dy, dz, color=colors, edgecolor='k', linewidth=0.5, alpha=0.9)

                    # Labels
                    ax.set_xlabel('Posterior Probability', fontsize=7, weight='bold')
                    ax.set_ylabel('Y (dummy)', fontsize=7, weight='bold')
                    ax.set_zlabel('Frequency', fontsize=7, weight='bold')
                    ax.set_title(f"{name} Posterior Probability (3D)", fontsize=12, weight='bold')

                    # View angle
                    ax.view_init(elev=30, azim=-60)
                    ax.tick_params(labelsize=9)

                    st.pyplot(fig, use_container_width=True)

            st.subheader("Interactive Scatter Plots: Posterior Comparison & Correctness")

            # Бүх algorithms-н posterior-г нэг dataframe-д бэлтгэх
            df_scatter = pd.DataFrame({
                "NB_Proba": results["NaiveBayes"]["y_proba"],
                "LR_Proba": results["LogisticRegression"]["y_proba"],
                "True_Label": y_test.values,
                "Tweet": X_test.values,
                "NB_Correct": results["NaiveBayes"]["y_pred"] == y_test,
                "LR_Correct": results["LogisticRegression"]["y_pred"] == y_test
            })

            # 2 columns for side-by-side display
            cols = st.columns(2)

            # Column 1: Posterior Probability Comparison (color = True Label)
            with cols[0]:
                fig1 = px.scatter(
                    df_scatter,
                    x="NB_Proba",
                    y="LR_Proba",
                    color="True_Label",
                    hover_data={
                        "Tweet": True,
                        "NB_Proba": ':.4f',
                        "LR_Proba": ':.4f',
                        "NB_Correct": True,
                        "LR_Correct": True,
                        "True_Label": True
                    },
                    labels={
                        "NB_Proba": "Naive Bayes Posterior (+ probability)",
                        "LR_Proba": "Logistic Regression Posterior (+ probability)"
                    },
                    title="Posterior Probability Comparison"
                )
                st.plotly_chart(fig1, use_container_width=True)

            # Column 2: Correct vs Incorrect Predictions (color = Both Correct)
            with cols[1]:
                df_scatter["Both_Correct"] = df_scatter["NB_Correct"] & df_scatter["LR_Correct"]
                fig2 = px.scatter(
                    df_scatter,
                    x="NB_Proba",
                    y="LR_Proba",
                    color="Both_Correct",
                    hover_data={
                        "Tweet": True,
                        "NB_Proba": ':.4f',
                        "LR_Proba": ':.4f',
                        "NB_Correct": True,
                        "LR_Correct": True,
                        "True_Label": True
                    },
                    labels={
                        "NB_Proba": "Naive Bayes Posterior (+ probability)",
                        "LR_Proba": "Logistic Regression Posterior (+ probability)"
                    },
                    title="Correct vs Incorrect Predictions"
                )
                st.plotly_chart(fig2, use_container_width=True)




else:
    st.info("⏳ Upload CSV to train and see posterior probability, prediction, correctness, and metrics.")
